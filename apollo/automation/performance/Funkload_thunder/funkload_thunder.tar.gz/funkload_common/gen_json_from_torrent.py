#!/usr/bin/env python
#coding: utf-8

import sys
import json
import base64

print sys.argv
with open(sys.argv[1], 'r') as fr:
    d = {'seed_encoded': True}
    d['seed_file'] = base64.b64encode(fr.read())
    with open(sys.argv[2], 'w') as fw:
        fw.write(json.dumps(d)) 
